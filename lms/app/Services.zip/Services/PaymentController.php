<?php

namespace App\Http\Controllers;

use App\Payment;
use Illuminate\Http\Request;
use App\Services\Payments\Thawani;
use Exception;
use Illuminate\Contracts\Session\Session;

class PaymentController extends Controller
{
    public function create (Request $request){

        
        $client= new Thawani(
            config('services.thawani.secret_key'),
            config('services.thawani.publishable_key'),
            'test'
        );

        $data=[
            'client_refrence_id'=>"Test payment 1",
            'mode'=>'payment',
            'products'=>[[
                'name'=>"test product",
                'unit_amount'=>102*100,
                'quantity'=>2,
            ],
            ],

            'success_url'=>route('payment.success'),
            'cancel_url'=>route('payment.cancel'),
            
            ];
            
            try{
        $session_id = $client->createCheckoutSession($data);

        $payment=Payment::forceCreate([
            'user_id'=>auth()->id(),
            'gateway'=>'thawani',
            'reference_id'=>$session_id,
            'amount'=>100*100,
            "status"=>"pending"
        ]);

        


        \Session::put('payment_id',$payment->id);
        \Session::put('session_id',$session_id);
        
        
        return redirect()->away($client->getPayUrl($session_id));
            }catch(Exception $e){
                
                dd($e->getMessage());

                // return redirect()->route('payment.cancel');
            }
    }

    
}
